# codepen-like-resizable-divs

A Pen created on CodePen.io. Original URL: [https://codepen.io/denishmistry7/pen/jOKgYZb](https://codepen.io/denishmistry7/pen/jOKgYZb).

